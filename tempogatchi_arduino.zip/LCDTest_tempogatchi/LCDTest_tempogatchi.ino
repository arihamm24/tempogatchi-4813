#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <SPI.h>
#include "image.h"

#define TFT_CS   10
#define TFT_DC    7
#define TFT_RST   8

Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST);

#define IMG_W 50
#define IMG_H 71
#define IMG_HEADER_BYTES 8
#define IMG_SCALE 5

#define IMG_X_OFFSET -10
#define IMG_Y_OFFSET 0
#define IMG_ROTATION 1   // 3 = -90 degrees / 270 degrees

void drawImageRGB888(const unsigned char* img) {
  for (int sy = 0; sy < IMG_H; sy++) {
    for (int sx = 0; sx < IMG_W; sx++) {

      int srcIndex = IMG_HEADER_BYTES + ((sy * IMG_W + sx) * 3);

      uint8_t r = pgm_read_byte(&img[srcIndex + 0]) * 4;
      uint8_t g = pgm_read_byte(&img[srcIndex + 1]) * 4;
      uint8_t b = pgm_read_byte(&img[srcIndex + 2]) * 4;

      uint16_t color = tft.color565(r, g, b);

      int dx, dy;

      // fixed -90 degree rotation
      dx = sy;
      dy = IMG_W - 1 - sx;

      tft.fillRect(
        IMG_X_OFFSET + dx * IMG_SCALE,
        IMG_Y_OFFSET + dy * IMG_SCALE,
        IMG_SCALE,
        IMG_SCALE,
        color
      );
    }
  }
}

void setup() {
  tft.init(240, 320);
  tft.setRotation(1);
  tft.fillScreen(ST77XX_BLACK);

}

void loop() {
  //drawImageRGB888(gImage_hello1);
  delay(1000);
  drawImageRGB888(gImage_hello2);
  delay(1000);
}
