#ifndef _IMAGE_H_
#define _IMAGE_H_

#include <avr/pgmspace.h>

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char gImage_hello1[] PROGMEM;
extern const unsigned char gImage_hello2[] PROGMEM;  // NEW

#ifdef __cplusplus
}
#endif

#endif